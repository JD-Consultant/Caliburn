"""Start one isolated, frozen product App with the established batch spend fence."""

import sys
import zipfile
from dataclasses import replace
from decimal import Decimal
from pathlib import Path

FROZEN = Path("/tmp/frozen")
with zipfile.ZipFile("/witness/freeze/sources.zip") as archive:
    for name in archive.namelist():
        if name.startswith("apps/api/src/"):
            archive.extract(name, FROZEN)
sys.path.insert(0, str(FROZEN / "apps/api/src"))
sys.path.insert(0, "/shared")

import httpx2  # noqa: E402
import uvicorn  # noqa: E402
from alembic import command  # noqa: E402
from alembic.config import Config  # noqa: E402

import caliburn.bootstrap as bootstrap  # noqa: E402
from batch_guard import BatchGuard, GuardedTransport  # noqa: E402
from caliburn.adapters.openai_credentials import read_openai_api_key  # noqa: E402
from caliburn.adapters.openai_responses import create_responses_client  # noqa: E402
from caliburn.settings import ModelSettings, Settings  # noqa: E402

guard = BatchGuard(limit=Decimal("0.30"), seconds=3600)


def guarded_client(*, api_key, timeout_seconds):
    transport = GuardedTransport(
        guard, httpx2.AsyncHTTPTransport(retries=0), "/witness/provider-trace.jsonl"
    )
    client = httpx2.AsyncClient(
        transport=transport, timeout=timeout_seconds, follow_redirects=False, trust_env=False
    )
    return create_responses_client(
        api_key=api_key, timeout_seconds=timeout_seconds, http_client=client
    )


if __name__ == "__main__":
    configuration = Config("/opt/caliburn/alembic.ini")
    command.upgrade(configuration, "head")
    configured = replace(
        Settings.from_environment(),
        model=ModelSettings(api_key=read_openai_api_key(Path("/secret/openai.env"))),
    )
    bootstrap.create_responses_client = guarded_client
    uvicorn.run(bootstrap.create_app(configured), host="0.0.0.0", port=8100, log_level="warning")
