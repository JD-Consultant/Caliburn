# 下一問、轉題與收尾：顧問指引對照

狀態：離線準備。使用者已同意本批最多 US$0.10／20 分鐘；外送開始後不重置界線、不補跑失敗，也不更新 8105／8106 Docker。

本批檢查：把「可編寫部分 JD」「可轉換焦點」「可結束整份訪談」集中定義，能否改善正常流程已清楚後的重要條件探索，同時避免重問及勉強延長訪談。

- 方法、假設及判準：[protocol.md](protocol.md)。
- 可見內容的局部調整：[case-overrides.json](case-overrides.json)。
- 員工回答規則及私人答案：[reply-policy.json](reply-policy.json)，只供評測者，不預載給顧問。
- 舊案例與前次失敗：[前批結果](../jd-condition-exploration-2026-10-07/results.md)。
- 接線：[run_comparison.py](run_comparison.py)。沿既有真顧問 Runner、隔離 PostgreSQL 及費用護欄，不另建 Agent loop。

模型固定 `gpt-6-luna`／high，輸出上限 16,384。舊版是本次修改前、已含條件探索規則的 Prompt，不是最早沒有探索規則的版本；兩版工具、Context、起始 JD 及原話相同。

準備與執行從 repo root 使用 `apps/api/.venv/Scripts/python.exe -X utf8 -B <本目錄>/run_comparison.py prepare`、`execute`。準備只建立新隔離 schema 及凍結包，不送模型請求。已存在 `started.json` 的資料包不得再次執行。

完成後在本目錄保存語意判讀、成品、工具路徑與用量；實測結果與一般品質結論分開。公版 HTTP 為固定合成 fixture，沒有背景 Memory 外送，不作真 RAG、超容量或整份職務訪談驗收。
